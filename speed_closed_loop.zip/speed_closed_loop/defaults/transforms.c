/*
 * transfroms.c
 *
 *  Created on: 23-May-2024
 *      Author: aniru
 */
#include "common.h"
#include "transforms.h"
//
// theta_elec must be in degrees
//
void clarke_parke(AMP_VOLT* p, float theta_elec)
{
    p->id = (p->ia)*cos(theta_elec) + (p->ia/sqrt(3) + 2*p->ib/sqrt(3))*sin(theta_elec);
    p->iq = -(p->ia)*sin(theta_elec) + (p->ia/sqrt(3) + 2*p->ib/sqrt(3))*cos(theta_elec);
}
void inv_parke(AMP_VOLT* p, float theta_elec)
{
    p->varef = p->vdref*cos(theta_elec) - p->vqref*sin(theta_elec);
    p->vbref = p->vdref*sin(theta_elec) - p->vqref*cos(theta_elec);
}

