/*
 * default.h
 *
 *  Created on: 22-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_COMMON_H_
#define DEFAULTS_COMMON_H_

#include "math.h"
#include "IQmathLib.h"
#include "F28x_Project.h"

#define SYSCLKOUT 100e6
#define RAMP_PERIOD 2000
#define PPR 1024
#define TB_PRD 5000
#define GAIN 4
#define TB_CLK 100000000
#define RPM_SET 1400
#define RPM_MAX 2000
#define INIT_PWM_CLK 763*GAIN
#define MPT_FACTOR 1.7435 // sqrt(2/(3 * POLE_PAIR * (Ld - Lq)))
                          // Ld and Lq are inductances based on the motor specs
#define INIT_THROTTLE 17.88
#define PWM_CLK   (5e3*GAIN)             // RPM/60 * PPR * GAIN
#define PWM_CLK_MAX 136533.33           // PRM_MAX/60 * PPR * GAIN
#define EXC_PWM_CLK 2048
#define SP        (TB_CLK/(2*PWM_CLK))
#define EXC_SP (TB_CLK/(2*EXC_PWM_CLK))
#define TBCTLVAL  0x200A           // up-down count, timebase=SYSCLKOUT
#define throttle_max 800
#define PI 3.141593
#define POLE_PAIR 2
#define POSSPEED_DEFAULTS {0x0, 0x0,0x0,0x0,0x0,16382,POLE_PAIR,0,0x0,\
                           250,0,RPM_MAX,0,\
                           0,0,0,0}
#define AMP_VOLT_DEFAULTS {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0}
#define STOP 0
#define STARTUP 1
#define RUNNING 2
#define PAUSE 3
#define EXC_THROTTLE 100
#define EXC_TIME 15000
#define CS_REF_V 3.3 // Current Sensor Reference Voltage(Enter in decimal)
#define CS_SENSTIVITY 0.039 // Current Sensor Sensitivity
#define CS_B3_OFFSET 7
#define CS_A3_OFFSET 0
#define CUR_AVERAGE 1000
#define SPEED_AVERAGE 50
#define CPU_INTERRUPT_PERIOD 1   // in us

typedef struct {int theta_elec;         // Output: Motor Electrical angle (Q15)
                int theta_mech;         // Output: Motor Mechanical Angle (Q15)
                int DirectionQep;       // Output: Motor rotation direction (Q0)
                int QEP_cnt_idx;        // Variable: Encoder counter index (Q0)
                int theta_raw;          // Variable: Raw angle from Timer 2 (Q0)
                int mech_scaler;        // Parameter: 0.9999/total count, total
                                        // count = 4000 (Q26)
                int pole_pairs;         // Parameter: Number of pole pairs (Q0)
                int cal_angle;          // Parameter: Raw angular offset
                                        // between encoder and phase a (Q0)
                int index_sync_flag;    // Output: Index sync status (Q0)

                unsigned long SpeedScaler;     // Parameter :  Scaler converting 1/N
                                        // cycles to a GLOBAL_Q speed (Q0) -
                                        // independently with global Q
                _iq Speed_pr;           // Output :  speed in per-unit
                int MaxRpm;         // Parameter : Scaler converting
                                        // GLOBAL_Q speed to rpm (Q0) speed -
                                        // independently with global Q
                float SpeedRpm_pr;      // Output : speed in r.p.m. (Q0) -
                                        // independently with global Q
                int oldpos;            // Input: Electrical angle (pu) (Q15)
                int Speed_fr;           // Output :  speed in per-unit
                int SpeedRpm_fr;      // Output : Speed in rpm  (Q15) -
                                        // independently with global Q
                                        // To get actual RPM this is to be divided by time taken for one QU_PRD = 250 *(1/200MHz)
                long *Tmp;
                }  POSSPEED;

typedef struct {
                float ia;
                float ib;
                float id;
                float iq;
                float vdref;
                float vqref;
                float varef;
                float vbref;
                }  AMP_VOLT;

#endif /* DEFAULTS_COMMON_H_ */
