/*
 * pwm.h
 *
 *  Created on: 18-May-2024
 *      Author: aniru
 */
#ifndef PWM_DEF_H_
#define PWM_DEF_H_

__interrupt void epwm4_isr();
__interrupt void epwm5_isr();
__interrupt void epwm6_isr();
void initepwm4(int);
void initepwm5(int);
void initepwm6(int);
void pwm(int);

__interrupt void epwm3_isr();
void initepwm3(float);

#endif /* PWM_DEF_H_ */
