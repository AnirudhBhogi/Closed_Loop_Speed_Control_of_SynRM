/*
 * qep.h
 *
 *  Created on: 19-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_QEP_H_
#define DEFAULTS_QEP_H_

#include "common.h"

typedef POSSPEED *POSSPEED_handle;

void initeqep1(void);
void initeqep2(void);
void POSSPEED_Calc(POSSPEED_handle);

#endif /* DEFAULTS_QEP_H_ */
