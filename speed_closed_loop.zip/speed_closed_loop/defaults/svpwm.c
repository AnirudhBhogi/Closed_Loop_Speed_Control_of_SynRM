/*
 * svpwm.c
 *
 *  Created on: 22-May-2024
 *      Author: aniru
 */
#include "common.h"
#include "svpwm.h"

//
// Describes 6 PWM's to be generates based on the sector of electrical cycle
// EPWMxA => HIGH SIDE, EPWMxB => LOW SIDE
// EPWM4,5,6 => PHASE A,B,C
//
void svpwm(int throttle, int theta_elec)
{
    int sector = 0;
    float T0, T1, T2;
    float elec_angle, sector_angle;

    elec_angle = 360.0 * (theta_elec/32768.0); // Since theta_elec is in Q16 format

    if(elec_angle >= 0)
    {
        if(elec_angle <= 60)
        {
            sector = 1;
            sector_angle = elec_angle;
        }
        else if(elec_angle <= 120)
        {
            sector = 2;
            sector_angle = elec_angle - 60;
        }
        else if(elec_angle <= 180)
        {
            sector = 3;
            sector_angle = elec_angle - 120;
        }
        else if(elec_angle <= 240)
        {
            sector = 4;
            sector_angle = elec_angle - 180;
        }
        else if(elec_angle <= 300)
        {
            sector = 5;
            sector_angle = elec_angle - 240;
        }
        else
        {
            sector = 6;
            sector_angle = elec_angle - 300;
        }
        T1 = ((float)throttle/throttle_max) * TB_PRD * 2 * sinf(sector_angle * PI / 180.0 );
        T2 = ((float)throttle/throttle_max) * TB_PRD * 2 * sinf((60.0 - sector_angle) * PI / 180.0);
        T0 = 2 * TB_PRD - T1 - T2;

        switch(sector)
        {
        case 1:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2 + T1/2);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2);
        break;
        case 2:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2 + T2/2);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
        break;
        case 3:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2 + T1/2);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
        break;
        case 4:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2 + T2/2);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2);
        break;
        case 5:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T2/2 + T1/2);
        break;
        case 6:
            EPwm4Regs.CMPA.bit.CMPA = (unsigned short)(T0/4);
            EPwm5Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2);
            EPwm6Regs.CMPA.bit.CMPA = (unsigned short)(T0/4 + T1/2 + T2/2);
        break;
        default:
            EPwm4Regs.CMPA.bit.CMPA = 0;
            EPwm5Regs.CMPA.bit.CMPA = 0;
            EPwm6Regs.CMPA.bit.CMPA = 0;
        }
    }
}



