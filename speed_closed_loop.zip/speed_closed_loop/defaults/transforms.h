/*
 * transforms.h
 *
 *  Created on: 23-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_TRANSFORMS_H_
#define DEFAULTS_TRANSFORMS_H_
#include "common.h"

void clarke_parke(AMP_VOLT*,float);
void inv_parke(AMP_VOLT*, float);

#endif /* DEFAULTS_TRANSFORMS_H_ */
