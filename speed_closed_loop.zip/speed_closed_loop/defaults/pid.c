/*
 * pid.c
 *
 *  Created on: 23-May-2024
 *      Author: aniru
 */
#include "common.h"
#include "pid.h"

extern float out = 0.0, prop = 0.0;
extern float prev_error_speed = 0.0, integ_speed = 0.0;
extern float prev_error_id = 0.0, integ_id = 0.0;
extern float prev_error_iq = 0.0, integ_iq = 0.0;
extern float pid_speed(float error)
{
    prop = Kp_speed * error;
//
//  Tustin Transform of Integral
//
    integ_speed += 0.5 * T * Ki_speed * (error + prev_error_speed);
//
//  Anti-Windup
//
    if(integ_speed > out_max_speed)
        integ_speed = out_max_speed;
    else if(integ_speed < out_min_speed)
        integ_speed = out_min_speed;
    else
        integ_speed = integ_speed;

    out = prop + integ_speed;

    if(out > out_max_speed)
        out = out_max_speed;
    else if(out < out_min_speed)
        out = out_min_speed;
    else
        out = out;

    prev_error_speed = error;
    return out;
}

float pid_id(float error)
{
    prop = Kp_id * error;
//
//  Tustin Transform of Integral
//
    integ_id += 0.5 * T * Ki_id * (error + prev_error_id);
//
//  Anti-Windup
//
    if(integ_id > out_max_id)
        integ_id = out_max_id;
    else if(integ_id < out_min_id)
        integ_id = out_min_id;
    else
        integ_id = integ_id;

    out = prop + integ_id;

    if(out > out_max_id)
        out = out_max_id;
    else if(out < out_min_id)
        out = out_min_id;
    else
        out = out;

    prev_error_id = error;
    return out;
}

float pid_iq(float error)
{
    prop = Kp_iq * error;
//
//  Tustin Transform of Integral
//
    integ_iq += 0.5 * T * Ki_iq * (error + prev_error_iq);
//
//  Anti-Windup
//
    if(integ_iq > out_max_iq)
        integ_iq = out_max_iq;
    else if(integ_iq < out_min_iq)
        integ_iq = out_min_iq;
    else
        integ_iq = integ_iq;

    out = prop + integ_iq;

    if(out > out_max_iq)
        out = out_max_iq;
    else if(out < out_min_iq)
        out = out_min_iq;
    else
        out = out;

    prev_error_iq = error;
    return out;
}

