/*
 * svpwm.h
 *
 *  Created on: 22-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_SVPWM_H_
#define DEFAULTS_SVPWM_H_

void svpwm(int,int);

#endif /* DEFAULTS_SVPWM_H_ */
