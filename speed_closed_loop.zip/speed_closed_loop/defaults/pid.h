/*
 * pid.h
 *
 *  Created on: 23-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_PID_H_
#define DEFAULTS_PID_H_

#include "common.h"

#define Kp_speed 0.01
#define Ki_speed 500
#define Kp_id 0.0
#define Ki_id 0.0
#define Kp_iq 0.0
#define Ki_iq 0.0
#define out_min_id 0.0
#define out_max_id 0.0
#define out_min_iq 0.0
#define out_max_iq 0.0
#define out_min_speed 0
#define out_max_speed 2000
#define T 0.6e-6f


float pid_speed(float error);
float pid_id(float);
float pid_iq(float);

#endif /* DEFAULTS_PID_H_ */
