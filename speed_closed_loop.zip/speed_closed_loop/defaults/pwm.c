/*
 * pwm.c
 *
 *  Created on: 18-May-2024
 *      Author: aniru
 */

#include "common.h"
#include "pwm.h"

int Interrupt_Count = 0;

void initepwm4(int state)
{
   //
   // Setup TBCLK
   //
   EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up
   EPwm4Regs.TBPRD = TB_PRD;       // Set timer period
   EPwm4Regs.TBCTL.bit.PHSEN = TB_DISABLE;    // Disable phase loading
   EPwm4Regs.TBPHS.bit.TBPHS = 0x0000;        // Phase is 0
   EPwm4Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV4;   // Clock ratio to SYSCLKOUT
   EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV4;

   //
   // Setup shadow register load on ZERO
   //
   EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
   EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
   EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

//   if(state == RUNNING)
   {
       EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
       EPwm4Regs.CMPB.bit.CMPB = 0;

       EPwm4Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
       EPwm4Regs.AQCTLA.bit.CAU = AQ_SET;
       EPwm4Regs.AQCTLA.bit.CAD = AQ_CLEAR;
       EPwm4Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
       EPwm4Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
       EPwm4Regs.AQCTLA.bit.PRD = AQ_CLEAR;

       EPwm4Regs.AQCTLB.bit.ZRO = AQ_SET;
       EPwm4Regs.AQCTLB.bit.CAU = AQ_CLEAR;
       EPwm4Regs.AQCTLB.bit.CAD = AQ_SET;
       EPwm4Regs.AQCTLB.bit.CBU = AQ_NO_ACTION;
       EPwm4Regs.AQCTLB.bit.CBD = AQ_NO_ACTION;
       EPwm4Regs.AQCTLB.bit.PRD = AQ_CLEAR;
       //
       // Dead-band Generator Control Register
       //
       EPwm4Regs.DBCTL.bit.IN_MODE = 3;  // EPWMxB is source for both RED and FED
       EPwm4Regs.DBCTL.bit.OUT_MODE = 3; // Enabling both Falling Edge delay(FED) and Rising edge Delay(RED)
       EPwm4Regs.DBCTL.bit.POLSEL = 2;
       EPwm4Regs.DBFED.bit.DBFED = 50;
       EPwm4Regs.DBRED.bit.DBRED = 50;
   }
//   else
//   {
//       EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
//       EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
//
//       EPwm4Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
//       EPwm4Regs.AQCTLA.bit.CAU = AQ_SET;
//       EPwm4Regs.AQCTLA.bit.CAD = AQ_CLEAR;
//       EPwm4Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
//       EPwm4Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
//
//       EPwm4Regs.AQCTLB.bit.ZRO = AQ_CLEAR;
//       EPwm4Regs.AQCTLB.bit.CAU = AQ_NO_ACTION;
//       EPwm4Regs.AQCTLB.bit.CAD = AQ_NO_ACTION;
//       EPwm4Regs.AQCTLB.bit.CBU = AQ_SET;
//       EPwm4Regs.AQCTLB.bit.CBD = AQ_CLEAR;
//   }

   //
   // Interrupt where we will change the Compare Values
   //
   EPwm4Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
   EPwm4Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm4Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event   ////////////////////////////////
}

void initepwm5(int state)
{
   //
   // Setup TBCLK
   //
   EPwm5Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up
   EPwm5Regs.TBPRD = TB_PRD;                  // Set timer period
   EPwm5Regs.TBCTL.bit.PHSEN = TB_DISABLE;    // Disable phase loading
   EPwm5Regs.TBPHS.bit.TBPHS = 0x0000;        // Phase is 0
   EPwm5Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm5Regs.TBCTL.bit.HSPCLKDIV = TB_DIV4;   // Clock ratio to SYSCLKOUT
   EPwm5Regs.TBCTL.bit.CLKDIV = TB_DIV4;

   //
   // Setup shadow register load on ZERO
   //
   EPwm5Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
   EPwm5Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   EPwm5Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
   EPwm5Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

//   if(state == RUNNING)
   {
       EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
       EPwm5Regs.CMPB.bit.CMPB = 0;

       EPwm5Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
       EPwm5Regs.AQCTLA.bit.CAU = AQ_SET;
       EPwm5Regs.AQCTLA.bit.CAD = AQ_CLEAR;
       EPwm5Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
       EPwm5Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
       EPwm5Regs.AQCTLA.bit.PRD = AQ_CLEAR;

       EPwm5Regs.AQCTLB.bit.ZRO = AQ_SET;
       EPwm5Regs.AQCTLB.bit.CAU = AQ_CLEAR;
       EPwm5Regs.AQCTLB.bit.CAD = AQ_SET;
       EPwm5Regs.AQCTLB.bit.CBU = AQ_NO_ACTION;
       EPwm5Regs.AQCTLB.bit.CBD = AQ_NO_ACTION;
       EPwm5Regs.AQCTLB.bit.PRD = AQ_CLEAR;

       //
       // Dead-band Generator Control Register
       //
       EPwm5Regs.DBCTL.bit.IN_MODE = 3;  // EPWMxB is source for both RED and FED
       EPwm5Regs.DBCTL.bit.OUT_MODE = 3; // Enabling both Falling Edge delay(FED) and Rising edge Delay(RED)
       EPwm5Regs.DBCTL.bit.POLSEL = 2;
       EPwm5Regs.DBFED.bit.DBFED = 50;
       EPwm5Regs.DBRED.bit.DBRED = 50;
   }
//   else
//   {
//       EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
//       EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
//
//       EPwm5Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
//       EPwm5Regs.AQCTLA.bit.CAU = AQ_SET;
//       EPwm5Regs.AQCTLA.bit.CAD = AQ_CLEAR;
//       EPwm5Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
//       EPwm5Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
//
//       EPwm5Regs.AQCTLB.bit.ZRO = AQ_CLEAR;
//       EPwm5Regs.AQCTLB.bit.CAU = AQ_NO_ACTION;
//       EPwm5Regs.AQCTLB.bit.CAD = AQ_NO_ACTION;
//       EPwm5Regs.AQCTLB.bit.CBU = AQ_SET;
//       EPwm5Regs.AQCTLB.bit.CBD = AQ_CLEAR;
//   }
   //
   // Interrupt where we will change the Compare Values
   //
   EPwm5Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
   EPwm5Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm5Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event   ////////////////////////////////
}

void initepwm6(int state)
{
   //
   // Setup TBCLK
   //
   EPwm6Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up
   EPwm6Regs.TBPRD = TB_PRD;       // Set timer period
   EPwm6Regs.TBCTL.bit.PHSEN = TB_DISABLE;    // Disable phase loading
   EPwm6Regs.TBPHS.bit.TBPHS = 0x0000;        // Phase is 0
   EPwm6Regs.TBCTR = 0x0000;                  // Clear counter
   EPwm6Regs.TBCTL.bit.HSPCLKDIV = TB_DIV4;   // Clock ratio to SYSCLKOUT
   EPwm6Regs.TBCTL.bit.CLKDIV = TB_DIV4;

   //
   // Setup shadow register load on ZERO
   //
   EPwm6Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
   EPwm6Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   EPwm6Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
   EPwm6Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

//   if(state == RUNNING)
   {
       EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
       EPwm6Regs.CMPB.bit.CMPB = 0;

       EPwm6Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
       EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;
       EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;
       EPwm6Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
       EPwm6Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
       EPwm6Regs.AQCTLA.bit.PRD = AQ_CLEAR;

       EPwm6Regs.AQCTLB.bit.ZRO = AQ_SET;
       EPwm6Regs.AQCTLB.bit.CAU = AQ_CLEAR;
       EPwm6Regs.AQCTLB.bit.CAD = AQ_SET;
       EPwm6Regs.AQCTLB.bit.CBU = AQ_NO_ACTION;
       EPwm6Regs.AQCTLB.bit.CBD = AQ_NO_ACTION;
       EPwm6Regs.AQCTLB.bit.PRD = AQ_CLEAR;

       //
       // Dead-band Generator Control Register
       //
       EPwm6Regs.DBCTL.bit.IN_MODE = 3;  // EPWMxB is source for both RED and FED
       EPwm6Regs.DBCTL.bit.OUT_MODE = 3; // Enabling both Falling Edge delay(FED) and Rising edge Delay(RED)
       EPwm6Regs.DBCTL.bit.POLSEL = 2;
       EPwm6Regs.DBFED.bit.DBFED = 50;
       EPwm6Regs.DBRED.bit.DBRED = 50;
   }
//   else
//   {
//       EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
//       EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
//
//       EPwm6Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
//       EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;
//       EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;
//       EPwm6Regs.AQCTLA.bit.CBU = AQ_NO_ACTION;
//       EPwm6Regs.AQCTLA.bit.CBD = AQ_NO_ACTION;
//
//       EPwm6Regs.AQCTLB.bit.ZRO = AQ_CLEAR;
//       EPwm6Regs.AQCTLB.bit.CAU = AQ_NO_ACTION;
//       EPwm6Regs.AQCTLB.bit.CAD = AQ_NO_ACTION;
//       EPwm6Regs.AQCTLB.bit.CBU = AQ_SET;
//       EPwm6Regs.AQCTLB.bit.CBD = AQ_CLEAR;
//   }

   //
   // Interrupt where we will change the Compare Values
   //
   EPwm6Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
   EPwm6Regs.ETSEL.bit.INTEN = 1;                // Enable INT
   EPwm6Regs.ETPS.bit.INTPRD = ET_3RD;           // Generate INT on 3rd event   ////////////////////////////////
}

__interrupt void epwm4_isr(void)
{
    //
    // Clear INT flag for this timer
    //
    EPwm4Regs.ETCLR.bit.INT = 1;

    //
    // Acknowledge this interrupt to receive more interrupts from group 3
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

__interrupt void epwm5_isr(void)
{
    //
    // Clear INT flag for this timer
    //
    EPwm5Regs.ETCLR.bit.INT = 1;

    //
    // Acknowledge this interrupt to receive more interrupts from group 3
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

__interrupt void epwm6_isr(void)
{
    //
    // Clear INT flag for this timer
    //
    EPwm6Regs.ETCLR.bit.INT = 1;

    //
    // Acknowledge this interrupt to receive more interrupts from group 3
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

void initepwm3(float sp)
{
    EPwm3Regs.TBSTS.all=0;
    EPwm3Regs.TBPHS.all =0;
    EPwm3Regs.TBCTR=0;

    EPwm3Regs.CMPCTL.all=0x50;     // immediate mode for CMPA and CMPB
    EPwm3Regs.CMPA.bit.CMPA=(int)sp/2;
    EPwm3Regs.CMPB.all=0;

    EPwm3Regs.AQCTLA.all=0x60;     // CTR=CMPA when inc->EPwm3A=1,
                                   // when dec->EPwm3A=0
    EPwm3Regs.AQCTLB.all=0x09;     // CTR=PRD ->EPwm3B=1, CTR=0 ->EPwm3B=0
    EPwm3Regs.AQSFRC.all=0;
    EPwm3Regs.AQCSFRC.all=0;

    EPwm3Regs.TZSEL.all=0;
    EPwm3Regs.TZCTL.all=0;
    EPwm3Regs.TZEINT.all=0;
    EPwm3Regs.TZFLG.all=0;
    EPwm3Regs.TZCLR.all=0;
    EPwm3Regs.TZFRC.all=0;

    EPwm3Regs.ETSEL.all=0x0A;      // Interrupt on PRD
    EPwm3Regs.ETPS.all=1;
    EPwm3Regs.ETFLG.all=0;
    EPwm3Regs.ETCLR.all=0;
    EPwm3Regs.ETFRC.all=0;

    EPwm3Regs.PCCTL.all=0;

    EPwm3Regs.TBCTL.all=0x0010+TBCTLVAL; // Enable Timer
    EPwm3Regs.TBPRD= (int)sp;
}


__interrupt void epwm3_isr(void)
{
    unsigned int i;
//   //
//   // Position and Speed measurement
//   //
//   qep_posspeed.calc(&qep_posspeed);

   //
   // Control loop code for position control & Speed control
   //
   Interrupt_Count++;
   //
   // Every 1000 __interrupts(4000 QCLK counts or 1 rev.)
   //
   if (Interrupt_Count==1000)
   {
       EALLOW;
       GpioDataRegs.GPASET.bit.GPIO0 = 1; // Pulse Index signal  (1 pulse/rev.)
       for (i=0; i<700; i++)
       {
       }
     GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;
       Interrupt_Count = 0;               // Reset count
       EDIS;
   }
   EPwm3Regs.ETCLR.bit.INT=1;
   //
   // Acknowledge this __interrupt to receive more __interrupts from group 1
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

void pwm(int sector)
{
    switch(sector)
    {
    case 0://6
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //ghb
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //glc
    break;
    case 1://4
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //gha
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //glc
    break;
    case 2://5
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //gha
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //glb
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
    break;
    case 3://1
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //glb
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //ghc
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
    break;
    case 4://3
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //gla
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //ghc
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
    break;
    case 5://2
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD - EXC_THROTTLE; //gla
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD - EXC_THROTTLE; //ghb
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
    break;
    default:
        EPwm4Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm4Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm5Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm5Regs.CMPB.bit.CMPB = TB_PRD;
        EPwm6Regs.CMPA.bit.CMPA = TB_PRD;
        EPwm6Regs.CMPB.bit.CMPB = TB_PRD;
    }
}

