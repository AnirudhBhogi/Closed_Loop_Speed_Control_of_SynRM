/*
 * adc.h
 *
 *  Created on: 25-May-2024
 *      Author: aniru
 */

#ifndef DEFAULTS_ADC_H_
#define DEFAULTS_ADC_H_

void ConfigureADC(void);
void SetupADCSoftware(void);

#endif /* DEFAULTS_ADC_H_ */
