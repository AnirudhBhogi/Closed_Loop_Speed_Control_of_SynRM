//
// Included Files
// Connections:
// PIN40 to PIN 51
// ePWMA(PIN36) to eQEP1-A
// ePWMB(PIN 35) to eQEP1-B
// ePWM6A,B = Rphase(Vin1,Vin2)
// ePWM5A,B = Yphase(Vin1,Vin2)
// ePWM4A,B = Bphase(Vin1,Vin2)
// In order to start the code GPIO19 needs to be connected to GND
// Connect either Encoder A/ABar or B/Bbar to GPIO26
//
#include "common.h"
#include "pwm.h"
#include "qep.h"
#include "svpwm.h"
#include "pid.h"
#include "adc.h"
#include "stdio.h"

void initxint1(void);
void initxint2(void);
__interrupt void qep1_isr(void);
interrupt void xint1_isr(void);
interrupt void xint2_isr(void);
__interrupt void adcb_evt_isr(void);
__interrupt void cpu_timer0_isr(void);
__interrupt void cpu_timer1_isr(void);

void scia_echoback_init(void);
void scia_fifo_init(void);
void scia_xmit(int a);
void scia_msg(char *msg);

float throttle = (PWM_CLK/PPR) * 60 * throttle_max / RPM_MAX / GAIN; // Max throttle is 800
//float throttle = 400;
float ia, ib;
int flag = 0;
float pid_out = 0.0;
float speed_input = 0.0;
float pi_speed_out = 0, pi_id = 0, pi_iq = 0, var_throttle = INIT_THROTTLE;
int state = STOP, pstate = STOP;
long counter1 = 0, counter2 = 0, counter3 = 0;
long sect = 0;
int ia_sign = 1, ib_sign = 1;
float id_ref = 0.0, iq_ref = 0.0;
int index_cnt = 0;
char *a;
unsigned int pos_count = 0;
long pwm_clk = INIT_PWM_CLK;
long sp, sp_prev, prev_speed;
long delta_t;
long speed_sensed = 0;
long prev_speed_sensed = 0;


POSSPEED qep_posspeed = POSSPEED_DEFAULTS;
AMP_VOLT cur_volt     = AMP_VOLT_DEFAULTS;

//
// Main
//
void main(void)
{
//
// Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the F2837xD_SysCtrl.c file.
//
    InitSysCtrl();
//
// Step 2. Initialize GPIO:
// This example function is found in the F2837xD_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
//
    InitGpio();
    GPIO_SetupPinMux(65, GPIO_MUX_CPU1, 0);
    GPIO_SetupPinOptions(65, GPIO_OUTPUT, GPIO_PUSHPULL);
//
// Enable PWM4, PWM5, PWM6, PWM3, QEP1
//
    CpuSysRegs.PCLKCR2.bit.EPWM3=1;
    CpuSysRegs.PCLKCR2.bit.EPWM4=1;
    CpuSysRegs.PCLKCR2.bit.EPWM5=1;
    CpuSysRegs.PCLKCR2.bit.EPWM6=1;
    CpuSysRegs.PCLKCR4.bit.EQEP1=1;
    CpuSysRegs.PCLKCR7.bit.SCI_A = 1;
//    CpuSysRegs.PCLKCR4.bit.EQEP2=1;
//
// For this case just init GPIO pins for ePWM4, ePWM5, ePWM6
// These functions are in the F2837xD_EPwm.c file
//
    InitEQep1Gpio();
    InitEPwm3Gpio();    // Encoder simulation
    InitEPwm4Gpio();
    InitEPwm5Gpio();
    InitEPwm6Gpio();
//
// For this example, only init the pins for the SCI-A port.
//  GPIO_SetupPinMux() - Sets the GPxMUX1/2 and GPyMUX1/2 register bits
//  GPIO_SetupPinOptions() - Sets the direction and configuration of the GPIOS
// These functions are found in the F2837xD_Gpio.c file.
//
#ifdef _LAUNCHXL_F2837xD
   GPIO_SetupPinMux(85, GPIO_MUX_CPU1, 5);
   GPIO_SetupPinOptions(85, GPIO_INPUT, GPIO_PUSHPULL);
   GPIO_SetupPinMux(84, GPIO_MUX_CPU1, 5);
   GPIO_SetupPinOptions(84, GPIO_OUTPUT, GPIO_ASYNC);
#else
  GPIO_SetupPinMux(43, GPIO_MUX_CPU1, 15);
  GPIO_SetupPinOptions(43, GPIO_INPUT, GPIO_PUSHPULL);
  GPIO_SetupPinMux(42, GPIO_MUX_CPU1, 15);
  GPIO_SetupPinOptions(42, GPIO_OUTPUT, GPIO_ASYNC);
#endif

    EALLOW;
    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;    // GPIO4 as output simulates Index signal
    GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;  // Normally low
    GpioCtrlRegs.GPADIR.bit.GPIO19 = 0; // INPUT
    GpioCtrlRegs.GPAPUD.bit.GPIO19 = 0;
    GpioDataRegs.GPASET.bit.GPIO19 = 1;
    EDIS;

//
// Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
//
    DINT;

//
// Initialize the PIE control registers to their default state.
// The default state is all PIE interrupts disabled and flags
// are cleared.
// This function is found in the F2837xD_PieCtrl.c file.
//
    InitPieCtrl();

//
// Disable CPU interrupts and clear all CPU interrupt flags:
//
    IER = 0x0000;
    IFR = 0x0000;

//
// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in F2837xD_DefaultIsr.c.
// This function is found in F2837xD_PieVect.c.
//
    InitPieVectTable();
//
// Interrupts that are used in this example are re-mapped to ISR functions found within this file.
//
    EALLOW; // This is needed to write to EALLOW protected registers
    PieVectTable.EPWM3_INT = &epwm3_isr;
    PieVectTable.EPWM4_INT = &epwm4_isr;
    PieVectTable.EPWM5_INT = &epwm5_isr;
    PieVectTable.EPWM6_INT = &epwm6_isr;
    PieVectTable.EQEP1_INT = &qep1_isr;
    PieVectTable.XINT1_INT = &xint1_isr;
    PieVectTable.XINT2_INT = &xint2_isr;
    PieVectTable.TIMER0_INT = &cpu_timer0_isr;
    PieVectTable.TIMER1_INT = &cpu_timer1_isr;
//    PieVectTable.ADCB_EVT_INT = &adcb_evt_isr;
    EDIS;   // This is needed to disable write to EALLOW protected registers
//
// Initialize the ePWM. eQEP
//
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    initepwm3(EXC_SP);
    initepwm4(state);
    initepwm5(state);
    initepwm6(state);
    initeqep1();
    initxint1();
    initxint2();
//    initeqep2();
    InitCpuTimers();

    scia_fifo_init();       // Initialize the SCI FIFO
    scia_echoback_init();   // Initialize SCI for echoback

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

//
// Configure CPU-Timer 0 to interrupt every second:
// 100MHz CPU Freq, 1 second Period (in uSeconds)
//
    ConfigCpuTimer(&CpuTimer0, 100, CPU_INTERRUPT_PERIOD);

//
// To ensure precise timing, use write-only instructions to write to the
// entire register. Therefore, if any of the configuration bits are changed in
// ConfigCpuTimer and InitCpuTimers (in F2837xD_cputimervars.h), the below
// settings must also be updated.
//
    CpuTimer0Regs.TCR.all = 0x4000;

    IER |= M_INT3;// For ePWM 1-12
    IER |= M_INT5;// For eQEP 1-3, CLB 1-4, SD 1-2
    IER |= M_INT1;// For ADCA,B,C; XINT 1-3
//    IER |= M_INT10;//For ADCA,B,C,D EVT & FEW OTHER ADC INT
    IER |= M_INT9;// For SCIA,B; CANA,B; USBA(CPU1 ONLY)
    IER |= M_INT1;// For CPU TIMER0
    IER |= M_INT13;// For CPU TIMER1
//
// Enable EPWM INTn in the PIE: Group 3 interrupt 4-6
// Enable EQEP INTn in the PIE: Group 5 interrupt 1
// Enable XINT INTn in the PIE: Group 1 interrupt 4
//
    PieCtrlRegs.PIEIER3.bit.INTx3 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx4 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx5 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx6 = 1;
    PieCtrlRegs.PIEIER5.bit.INTx1 = 1;// EQEP1 INTERRUPT
//    PieCtrlRegs.PIEIER5.bit.INTx2 = 1;// EQEP2 INTERRUPT
    PieCtrlRegs.PIEIER1.bit.INTx4 = 1;// XINT1 INTERRUPT
    PieCtrlRegs.PIEIER1.bit.INTx5 = 1;// XINT2 INTERRUPT
//    PieCtrlRegs.PIEIER10.bit.INTx5 = 1; // For ADCB_EVT Interrupt
    PieCtrlRegs.PIEIER9.bit.INTx1 = 1; // SCIA RX INTERRUPT
    PieCtrlRegs.PIEIER9.bit.INTx2 = 1; // SCIA TX INTERRUPT
//    PieCtrlRegs.PIEIER10.bit.INTx3 = 1;// ADCA3 INTERRUPT
//    PieCtrlRegs.PIEIER10.bit.INTx6 = 1;// ADCB2 INTERRUPT
//    PieCtrlRegs.PIEIER10.bit.INTx7 = 1;// ADCB3 INTERRUPT
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;// TINT0 INTERRUPT
//
// Setup ADC
//
    ConfigureADC();
    SetupADCSoftware();
//
// Enable global Interrupts and higher priority real-time debug events:
//
    EINT;  // Enable Global interrupt INTM
    ERTM;  // Enable Global realtime interrupt DBGM
//
// IDLE loop. Just sit and loop forever (optional):
//
    while(1)
    {
        if(EQep1Regs.QFLG.bit.IEL == 1)
        {
    //        state = RUNNING;
            EQep1Regs.QEPCTL.bit.SWI = 1;
            EQep1Regs.QCLR.bit.IEL = 1;
            EQep1Regs.QCLR.bit.INT = 1;
        }

//            cur_volt.ia = 0;
//            cur_volt.ib = 0;
//            counter1 = 0;
//            while(counter1 != CUR_AVERAGE)
//            {
//            AdcaRegs.ADCSOCFRC1.all = 0x0002; //SOC1
//            //
//            //start conversions immediately via software, ADCB
//            //
//            AdcbRegs.ADCSOCFRC1.all = 0x0006; //SOC2, SOC1
//            //
//            //wait for ADCA to complete, then acknowledge flag
//            //
//            while(AdcaRegs.ADCINTFLG.bit.ADCINT1 == 0);
//            AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
//            //
//            //wait for ADCB to complete, then acknowledge flag
//            //
//            while(AdcbRegs.ADCINTFLG.bit.ADCINT2 == 0);
//            AdcbRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
//            while(AdcbRegs.ADCINTFLG.bit.ADCINT1 == 0);
//            AdcbRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
//
//    //        if(AdcbResultRegs.ADCRESULT2 > 3990)
//    //            var_throttle = 780;
//    //        else
//    //        {
//    //            var_throttle = (AdcbResultRegs.ADCRESULT2/4095.0) * throttle_max;
//    //        }
//    //        cur_volt.ia = (CS_REF_V/2.0 + CS_OFFSET +  (AdcbResultRegs.ADCRESULT2 / 4095.0) / CS_SENSTIVITY) * ia_sign;
//    //        cur_volt.ib = (CS_REF_V/2.0 + CS_OFFSET +  (AdcbResultRegs.ADCRESULT1 / 4095.0) / CS_SENSTIVITY) * ib_sign;
//            cur_volt.ia += AdcaResultRegs.ADCRESULT1;
//            cur_volt.ib += AdcbResultRegs.ADCRESULT1;
//            counter1++;
//            }
//            cur_volt.ia /= CUR_AVERAGE;
//            cur_volt.ib /= CUR_AVERAGE;
//            cur_volt.ia += CS_A3_OFFSET;
//            cur_volt.ib += CS_B3_OFFSET;

            switch(state)
            {
            case STOP:
                if(GpioDataRegs.GPADAT.bit.GPIO19 == 0)
                {
//                    state = STARTUP;
                    state = RUNNING;
                    EPwm3Regs.CMPA.bit.CMPA = 0;
                    EPwm3Regs.TBPRD = 0;
                    ConfigCpuTimer(&CpuTimer1, 100, RAMP_PERIOD);
                    CpuTimer1Regs.TCR.all = 0x4000;
                }
                pstate = STOP;
            break;

            case STARTUP:
                POSSPEED_Calc(&qep_posspeed);
                svpwm(var_throttle, qep_posspeed.theta_elec);
//                svpwm(throttle, qep_posspeed.theta_elec);
                pstate = STARTUP;
            break;

            case RUNNING:
                if((pstate == STARTUP) || (pstate == STOP))
                {
                    initepwm3(SP);
                }
                POSSPEED_Calc(&qep_posspeed);
//                speed_input = (int)((throttle/throttle_max) * qep_posspeed.MaxRpm);

    //          Sensored FOC for SynRM has id = iq
    //            clarke_parke(&cur_volt, qep_posspeed/32768.0 * 360.0);
    //            iq_ref = pid_speed(speed_input - qep_posspeed.SpeedRpm_pr);
    //            cur_volt.vqref = pid_iq(iq_ref - cur_volt.iq);
    //            cur_volt.vdref = pid_id(iq_ref - cur_volt.id);
    //            inv_parke(&cur_volt, qep_posspeed.theta_elec/32768.0 * 360.0);
    //            svpwm(sqrt(cur_volt.varef * cur_volt.varef + cur_volt.vbref * cur_volt.vbref), qep_posspeed.theta_elec);
    //          Note:
    //          In the svpwm block above the reference voltage vector goes as the input

    //          SVPWM Based Speed Closed Loop
//                pi_throttle =  pid_speed(speed_input - qep_posspeed.SpeedRpm_pr);
//                prev_speed = qep_posspeed.SpeedRpm_pr;
//                qep_posspeed.SpeedRpm_pr = (int)((60.0 * 1000000) / (2 * PPR * delta_t));
//                if((qep_posspeed.SpeedRpm_pr - prev_speed)>=10)
//                    qep_posspeed.SpeedRpm_pr = prev_speed;
//                prev_speed_sensed = speed_sensed;
//                speed_sensed = ((60 * 1000000) / (2 * PPR * delta_t));
//                if(abs(speed_sensed - prev_speed_sensed) >= 30)
//                    speed_sensed = prev_speed_sensed;
//                pi_speed_out =  pid_speed(RPM_SET - qep_posspeed.SpeedRpm_pr);
//                speed_sensed = ((60 * 1000000) / (2 * PPR * delta_t));

                if(counter3 < SPEED_AVERAGE)
                {
                    if(delta_t == 0)
                        speed_sensed += 0;
                    else if(delta_t <= 29)
                        speed_sensed += RPM_MAX;
                    else
                        speed_sensed += (58594/delta_t); // 10^6 / (1 * PPR * delta_t) * 60
                    counter3++;
                }
                else //(counter3 == SPEED_AVERAGE)
                {
                    speed_sensed /= SPEED_AVERAGE;
                    prev_speed_sensed = speed_sensed;

                    // Using SPEED_PI
                    pi_speed_out = pid_speed(RPM_SET - speed_sensed);

                    // Voltage vector magnitude and frequency calculation
                    pwm_clk = (pi_speed_out * PPR * GAIN)/60;
                    throttle = (throttle_max * pwm_clk)/PWM_CLK_MAX;

                    // TIMER(SIMULATED ENCODER) FREQUENCY INITIALIZATION
                    sp = (TB_CLK)/(2 * pwm_clk);
                    EPwm3Regs.CMPA.bit.CMPA = (int)sp/2;
                    EPwm3Regs.TBPRD = (int)sp;
//
                    //
                    // UART
//                    sprintf(a,"%ld",speed_sensed);
//                    sprintf(a,"%d,%d",(int)cur_volt.ia,cur_volt.ib);
                    sprintf(a,"%ld",speed_sensed);
                    scia_msg(a);

                    counter3 = 0;
                    speed_sensed = 0;
                }
                //SVPWM INITIALIZATION
                svpwm(throttle,qep_posspeed.theta_elec);

                pstate = RUNNING;
            break;

            default:
                state = STOP;
            }
    }
}

void initxint1()
{
    EALLOW;
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0;         // GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO25 = 0;          // input
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 0;        // XINT1 Synch to SYSCLKOUT only
    GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 2;        // XINT1 Synch to SYSCLKOUT only

//    GpioCtrlRegs.GPACTRL.bit.QUALPRD0 = 0x7f;   // Each sampling window
    GpioCtrlRegs.GPACTRL.bit.QUALPRD0 = 0xff;   // Each sampling window
                                                // is 510*SYSCLKOUT
    EDIS;
    GPIO_SetupXINT1Gpio(25);
    XintRegs.XINT1CR.bit.POLARITY = 1;          // Rising Edge Interrupt
    XintRegs.XINT1CR.bit.ENABLE = 1;            // Enable XINT1
}
void initxint2()
{
    EALLOW;
//    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;         // GPIO
//    GpioCtrlRegs.GPADIR.bit.GPIO27 = 0;          // input
//    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 1;
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0;         // GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 0;          // input

    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 1;//XINT2 Synch to SYSCLOCKOUT ONLY
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO27 = 1;

    GpioCtrlRegs.GPACTRL.bit.QUALPRD3 = 0x04;   // Each sampling window
//    GpioCtrlRegs.GPACTRL.bit.QUALPRD0 = 0xff;   // Each sampling window
                                                // is 510*SYSCLKOUT
    EDIS;
//    GPIO_SetupXINT2Gpio(27);
    GPIO_SetupXINT2Gpio(26);
    XintRegs.XINT2CR.bit.POLARITY = 1;          // Falling and Rising Edge Interrupt
    XintRegs.XINT2CR.bit.ENABLE = 1;            // Enable XINT2
}

interrupt void xint1_isr()
{
   if((state == STARTUP))// || (state == RUNNING && (qep_posspeed.theta_mech >= 30000)))
        EQep1Regs.QFRC.bit.IEL = 1;
   index_cnt++;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

interrupt void xint2_isr()
{
    //Low Speed Sensing
    if(counter2 >= 1465e4)
        qep_posspeed.SpeedRpm_pr = 2000;
    else
    {
        delta_t = counter2 * CPU_INTERRUPT_PERIOD; // in us
//        prev_speed_sensed = speed_sensed;

//        delta_t = (float)XintRegs.XINT2CTR.bit.INTCTR/(float)SYSCLKOUT;
    }
    counter2 = 0;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//
// cpu_timer0_isr - CPU Timer0 ISR with interrupt counter
//
__interrupt void cpu_timer0_isr(void)
{
    counter2++;
    if(counter2 > 29787)
        counter2 = 0;
   //
   // Acknowledge this interrupt to receive more interrupts from group 1
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
__interrupt void cpu_timer1_isr(void)
{
    if(state == STARTUP)
    {
        if(pwm_clk != PWM_CLK)
        {
            var_throttle += 0.023;
            pwm_clk += (1 * GAIN);
            sp_prev = sp;
            sp = 0.5 * (TB_CLK)/(pwm_clk);
            if(sp < 0)
            {
                sp = sp_prev;
            }
            DINT;
            EPwm3Regs.CMPA.bit.CMPA = (int)sp/2;
            EPwm3Regs.TBPRD = (int)sp;
            EINT;
        }
        else
            state = RUNNING;
    }
}
//
//  scia_echoback_init - Test 1,SCIA  DLB, 8-bit word, baud rate 0x000F,
//                       default, 1 STOP bit, no parity
//
void scia_echoback_init()
{
    //
    // Note: Clocks were turned on to the SCIA peripheral
    // in the InitSysCtrl() function
    //

    SciaRegs.SCICCR.all = 0x0007;   // 1 stop bit,  No loopback
                                    // No parity,8 char bits,
                                    // async mode, idle-line protocol
    SciaRegs.SCICTL1.all = 0x0003;  // enable TX, RX, internal SCICLK,
                                    // Disable RX ERR, SLEEP, TXWAKE
    SciaRegs.SCICTL2.all = 0x0003;
    SciaRegs.SCICTL2.bit.TXINTENA = 1;
    SciaRegs.SCICTL2.bit.RXBKINTENA = 1;

    //
    // SCIA at 9600 baud
    // @LSPCLK = 50 MHz (200 MHz SYSCLK) HBAUD = 0x02 and LBAUD = 0x8B.
    // @LSPCLK = 30 MHz (120 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x86.
    // @LSPCLK = 25 MHz (100 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x45.
    // SCIA at 115200 baud
    // @LSPCLK = 25 MHz (100 MHz SYSCLK) HBAUD = 0x00 and LBAUD = 0x1A.
    //
    SciaRegs.SCIHBAUD.all = 0x0000;
    SciaRegs.SCILBAUD.all = 0x001A;

    SciaRegs.SCICTL1.all = 0x0023;  // Relinquish SCI from Reset
}

//
// scia_xmit - Transmit a character from the SCI
//
void scia_xmit(int a)
{
    while (SciaRegs.SCIFFTX.bit.TXFFST != 0) {}
    SciaRegs.SCITXBUF.all =a;
}

//
// scia_msg - Transmit message via SCIA
//
void scia_msg(char * msg)
{
    int i;
    i = 0;
    while(msg[i] != '\0')
    {
        scia_xmit(msg[i]);
        i++;
    }
    scia_xmit('\n');
    scia_xmit('\r');
}

//
// scia_fifo_init - Initialize the SCI FIFO
//
void scia_fifo_init()
{
    SciaRegs.SCIFFTX.all = 0xE040;
    SciaRegs.SCIFFRX.all = 0x2044;
    SciaRegs.SCIFFCT.all = 0x0;
}
//
// Unit Timeout Interrupt
//
__interrupt void qep1_isr()
{
//    if(EQep1Regs.QFLG.bit.IEL == 1)
//    {
////        state = RUNNING;
//        EQep1Regs.QEPCTL.bit.SWI = 1;
//        EQep1Regs.QCLR.bit.IEL = 1;
//        EQep1Regs.QCLR.bit.INT = 1;
//    }
//    if(EQep1Regs.QFLG.bit.UTO == 1)
//    {
//        long tmp;
//        float delta_t;
//        cur_volt.ia = 0;
//        cur_volt.ib = 0;
//        counter1 = 0;
//        while(counter1 != CUR_AVERAGE)
//        {
//        AdcaRegs.ADCSOCFRC1.all = 0x0002; //SOC1
//        //
//        //start conversions immediately via software, ADCB
//        //
//        AdcbRegs.ADCSOCFRC1.all = 0x0006; //SOC2, SOC1
//        //
//        //wait for ADCA to complete, then acknowledge flag
//        //
//        while(AdcaRegs.ADCINTFLG.bit.ADCINT1 == 0);
//        AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
//        //
//        //wait for ADCB to complete, then acknowledge flag
//        //
////        while(AdcbRegs.ADCINTFLG.bit.ADCINT2 == 0);
////        AdcbRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;
//        while(AdcbRegs.ADCINTFLG.bit.ADCINT1 == 0);
//        AdcbRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
//
////        if(AdcbResultRegs.ADCRESULT2 > 3990)
////            var_throttle = 780;
////        else
////        {
////            var_throttle = (AdcbResultRegs.ADCRESULT2/4095.0) * throttle_max;
////        }
////        cur_volt.ia = (CS_REF_V/2.0 + CS_OFFSET +  (AdcbResultRegs.ADCRESULT2 / 4095.0) / CS_SENSTIVITY) * ia_sign;
////        cur_volt.ib = (CS_REF_V/2.0 + CS_OFFSET +  (AdcbResultRegs.ADCRESULT1 / 4095.0) / CS_SENSTIVITY) * ib_sign;
//        cur_volt.ia += AdcaResultRegs.ADCRESULT1;
//        cur_volt.ib += AdcbResultRegs.ADCRESULT1;
//        counter1++;
//        }
//        cur_volt.ia /= CUR_AVERAGE;
//        cur_volt.ib /= CUR_AVERAGE;
//        cur_volt.ia += CS_A3_OFFSET;
//        cur_volt.ib += CS_B3_OFFSET;
//        switch(state)
//        {
//        case STOP:
//            if(throttle > 0)
//                state = STARTUP;
//            pstate = STOP;
//        break;
//
//        case STARTUP:
////            if(counter2 == 10)
////            {
////                counter2 = 0;
////                sect = (++sect) % 6;
////                pwm(sect);
////            }
////            else
////                counter2++;
//            if(index_cnt == 2)
//                state = RUNNING;
//            POSSPEED_Calc(&qep_posspeed);
//            svpwm(EXC_THROTTLE, qep_posspeed.theta_elec);
//            pstate = STARTUP;
//        break;
//
//        case RUNNING:
//            if(pstate == STARTUP)
//            {
//                initepwm3(SP);
//            }
////            else
////                counter2++;
//            POSSPEED_Calc(&qep_posspeed);
//            speed_input = (throttle/throttle_max) * qep_posspeed.MaxRpm;
//
//            //Low Speed Sensing
////            if(EQep2Regs.QEPSTS.bit.UPEVNT) // Unit Position Event
////            {
////                flag++;
////                if(!EQep2Regs.QEPSTS.bit.COEF) // No capture Overflow
////                    tmp = (long)EQep2Regs.QCPRDLAT; // QCPRD gives instantaneous period whereas QCPRDLAT gives historical and stable value of period of unit position event
////                else
////                    tmp = 0xffffffff;
////
////                delta_t = (float)tmp / SYSCLKOUT;
////                qep_posspeed.SpeedRpm_pr = 60.0 / (4 * PPR * delta_t);
////
////                EQep2Regs.QEPSTS.bit.UPEVNT = 1;
////                EQep2Regs.QEPSTS.bit.COEF = 1;
////            }
//
////            qep_posspeed.SpeedRpm_pr = (counter2 * 60.0 * SYSCLKOUT)/(250.0 * PPR * 4);
////            counter2 = 0;
////          Sensored FOC for SynRM has id = iq
////            clarke_parke(&cur_volt, qep_posspeed/32768.0 * 360.0);
////            iq_ref = pid_speed(speed_input - qep_posspeed.SpeedRpm_pr);
////            cur_volt.vqref = pid_iq(iq_ref - cur_volt.iq);
////            cur_volt.vdref = pid_id(iq_ref - cur_volt.id);
////            inv_parke(&cur_volt, qep_posspeed.theta_elec/32768.0 * 360.0);
////            svpwm(sqrt(cur_volt.varef * cur_volt.varef + cur_volt.vbref * cur_volt.vbref), qep_posspeed.theta_elec);
////          Note:
////          In the svpwm block above the reference voltage vector goes as the input
//
////          SVPWM Based Speed Closed Loop
////            pi_throttle =  pid_speed(speed_input - qep_posspeed.SpeedRpm_pr);
////            svpwm(pi_throttle,qep_posspeed.theta_elec);
//
////          SVPWM based Open Loop
//            svpwm(throttle, qep_posspeed.theta_elec);
//            pstate = RUNNING;
//        break;
//
//        default:
//            state = STOP;
//        }
//        EQep1Regs.QCLR.bit.UTO = 1;
//        EQep1Regs.QCLR.bit.INT = 1;
//    }
////    PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;
//    sprintf(a,"%d,%d,%d",qep_posspeed.theta_elec,(int)cur_volt.ia,(int)cur_volt.ib);
//    scia_msg(a);
}

//
// Zero Crossing Interrupt
//
//__interrupt void adcb_evt_isr()
//{
//    if(AdcbRegs.ADCEVTSTAT.bit.PPB1ZERO == 1)
//    {
//        ib_sign = ~ib_sign;
//        AdcbRegs.ADCEVTCLR.bit.PPB1ZERO = 1;
//    }
//    if(AdcbRegs.ADCEVTSTAT.bit.PPB2ZERO == 1)
//    {
//        ia_sign = ~ia_sign;
//        AdcbRegs.ADCEVTCLR.bit.PPB2ZERO = 1;
//    }
//    PieCtrlRegs.PIEACK.all = PIEACK_GROUP10;
//}
//
// End of file
//
